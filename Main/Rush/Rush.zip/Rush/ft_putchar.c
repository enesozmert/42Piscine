#include <unistd.h>

void ft_putcharcharn(char x)
{
	write(1, &x, 1);
}
