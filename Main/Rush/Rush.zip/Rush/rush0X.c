#include <unistd.h>
#include <stdio.h>
#include <ft_putchar.c>

int _x;
int _y;

void rush(int x,int y)
{
	_x = x;
	_y = y;
	
	
	start_end();
}

void start_end(int row , int col)
{
	if ((row == 1  && col == 1) || (col == _x  && row == _y)) 
	{
		ft_putchar('/');
	}else if((col == 1 && row == _y) || row == 1 && (col == _x))
	{
		ft_putchar('\\');
	}
}

void middle()
{
	while()
	{

	}
}

void point(int x , int y)
{
	int col;
	int row;
	
	row = x;
	while(row <= x)
	{
		while(col <= y)
		{
			
			col++;
		}
		col = 0;
		row++;
	}
}
