#include <unistd.h>
#include <stdio.h>
#include <rush0X.h>

int main(void)
{
rush(5, 3);
return (0);
}
